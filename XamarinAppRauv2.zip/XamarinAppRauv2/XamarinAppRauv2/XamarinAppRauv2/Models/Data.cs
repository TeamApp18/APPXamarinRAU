﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XamarinAppRauv2
{
     public class Data
    {
        public string Name { get; set; }
        public double Cost { get; set; }
        public string ContactImage { get; set; }
    }
}
